<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class projectnew extends Model
{
    use HasFactory;
    protected $table = 'projectnew';
	public $timestamps = false;
    
}
