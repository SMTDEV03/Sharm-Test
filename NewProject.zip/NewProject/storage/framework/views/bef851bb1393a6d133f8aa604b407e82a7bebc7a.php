<!DOCTPE html>
<html>
<head>
<title>View Student Records</title>
</head>
<body>
<form action="/edit" method="POST">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" value="<?php echo e($data['id']); ?>" ><br><br>   
Name: <input type="text" name="fname" value="<?php echo e($data['fname']); ?>" ><br><br>    
Email:<input type="text" name="email" value="<?php echo e($data['email']); ?>" ><br><br>
Phone:<input type="text" name="phone" value="<?php echo e($data['phone']); ?>" ><br><br>
<button type="submit" name="submit">Updated</button>
</form>
</body>
</html><?php /**PATH C:\xamppp\htdocs\NewProject\resources\views/EditRecord.blade.php ENDPATH**/ ?>